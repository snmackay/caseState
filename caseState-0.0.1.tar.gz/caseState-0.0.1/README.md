# caseState
a case/switch statement library for python applications (since Python has no inbuilt one)
