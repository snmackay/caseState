import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="caseState",
    version="0.0.1",
    author="Sean Mackay",
    author_email="seannmackay@gmail.com",
    description="A case statement package for Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/snmackay/caseState.git",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GNU License",
        "Operating System :: OS Independent",
    ],
)
